CINETHZY Android starter project
=================================

This is a working Android WebView starter app with an offline-friendly anime catalog UI.
It does NOT include copyrighted anime episodes or unauthorized streams.

OPEN IN ANDROID STUDIO
1. Extract this ZIP.
2. Open the CINETHZY_Android_Source folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

To build an APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)

CONTENT / TAGALOG AUDIO
- The sample cards are demo catalog entries.
- To add licensed content, edit app/src/main/assets/index.html.
- Replace each item's video URL with a stream URL you own or are licensed to use.
- Add a Tagalog audio track only when you have distribution rights to that dub.
- The player accepts standard MP4/HLS links supported by Android WebView; HLS support varies by device.

This is a starter prototype, not a Netflix-scale service. A production service needs a backend,
licensed content agreements, secure video hosting/CDN, user accounts, and moderation.
